package oracle.apps.projects.model;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import org.apache.commons.lang.RandomStringUtils;

public class GenerateFile implements Runnable {
   public static BufferedWriter fileWriter=null;
    public static int threadCount = 0, lineCount = 0, x, minLineCount = 10000;
   
    public GenerateFile(int threadNo) {
        super();
        
       if(threadNo*minLineCount >=minLineCount&&threadNo<threadCount){
            //Assign a minLineCount to be written by each thread
            lineCount = minLineCount;
        }else{
           //Assign the remaining linecounts to be written by each thread 
            lineCount =x>minLineCount?x-(minLineCount*(threadNo-1)):x;
        }
       
    }

    public static void main(String[] args) {
           
           
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the number of lines");
            x= sc.nextInt();

            try{
            
                if(x<=minLineCount){
                    threadCount=1;
                    lineCount = x;
                }else{   
                    if(x%minLineCount > 0){
                        threadCount=x/minLineCount +1;
                    }else{
                        threadCount=x/minLineCount;
                    }
                }
               
                fileWriter =new BufferedWriter(new FileWriter(new File("RandomStringFile.txt")));

                for(int i =0;i<threadCount;i++){
                   
                    GenerateFile gf =new GenerateFile(i+1);
                    gf.run();
                   
                }

            }catch(IOException e){
                e.printStackTrace();
            }finally{
                try{
                    fileWriter.close();
                }catch(Exception e){
                    e.printStackTrace();
                }
                    
            }
    }
    public void run(){
        
        try {
            for(int i=0;i<lineCount;i++){
                fileWriter.write(RandomStringUtils.random(100, true, true));
                fileWriter.newLine();
            }        
        } catch (IOException ioe) {
            ioe.printStackTrace();
            try {
                fileWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
